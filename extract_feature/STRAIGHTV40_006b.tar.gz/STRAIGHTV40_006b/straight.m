%	Starter command for GUI-STRAIGHT

straightCIv1 GUIinitialize
